﻿namespace FenXianRouteLasteZm
{
    public class boolean
    {
    }
}